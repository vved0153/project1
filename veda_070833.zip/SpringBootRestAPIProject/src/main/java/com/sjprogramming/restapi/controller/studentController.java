package com.sjprogramming.restapi.controller;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

//import org.springframework.http.HttpStatus;
import com.sjprogramming.restapi.entity.student;
import com.sjprogramming.restapi.repository.studentRepository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
@RestController
public class studentController {
	
	@Autowired
	studentRepository repo;
	//get all guests
	//localhost:8080/students
	@GetMapping("/students")
	public List<student>getAllstudents(){
		List<student> students = repo.findAll();
		return students;
	}

@GetMapping("/students/{id}")
public student getstudent(@PathVariable int id) {
	student student = repo.findById(id).get();
	
	
	return student;
	
}

@PostMapping("/students/add")
@ResponseStatus(code = HttpStatus.CREATED)
public void createstudent(@RequestBody student student) {
	repo.save(student);
}

@PutMapping("/students/update/{id}")
public student updateGuests(@PathVariable int id) {
	repo.findById(id);
	student student = repo.findById(id).get();
	student.setName("Abhijith");
	student.setPercentage(85);
	repo.save(student);
	return student;
}
@DeleteMapping("/students/delete/{id}")
public void removeGuest(@PathVariable int id) {
	student student = repo.findById(id).get();
	repo.delete(student);
}
}
